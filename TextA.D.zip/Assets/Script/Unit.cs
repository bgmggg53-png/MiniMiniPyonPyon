﻿using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Unit: 게임 내 유닛(플레이어, 적 등)을 표현하는 컴포넌트 예시.
/// 이 파일은 초심자도 이해하기 쉽도록 매우 자세한 주석을 포함합니다.
/// - 데이터(스탯, 스킬)는 인스턴스 필드로 보관합니다.
/// - JobDataSO 등에서 값을 복사해서 초기화하는 패턴을 사용합니다.
/// - 스킬 실행, 상태 이상, 애니메이션 등 복잡한 동작은 별도 시스템으로 분리하세요.
/// </summary>
public class Unit : MonoBehaviour
{
    // -----------------------
    // 식별 정보 (디버그/UI용)
    // -----------------------
    [Header("식별")]
    // unitId: JobDataSO.id 또는 유닛 고유 ID로 사용.
    // - 예: "knight", "enemy_001" 등.
    public string unitId;

    // displayName: UI나 로그에 표시할 이름(예: "기사 토르").
    public string displayName;
    // -----------------------
    // 기본 스탯 (런타임에서 변경 가능한 값들)
    // -----------------------
    [Header("런타임 스탯")]
    // 공격력: 물리/기본 공격에 더해지는 수치
    public int atk;

    // 방어력: 받는 피해를 줄이는 수치(데미지 계산 시 사용)
    public int def;

    // 최대 체력 및 현재 체력
    public int maxHP;
    public int hp;

    // 최대 마나 및 현재 마나
    public int maxMP;
    public int mp;
    // 이동 속도/행동 속도 등으로 쓸 수 있는 스피드 값
    public int spd;

    // 행운 수치: 크리티컬 확률 등 다양한 용도로 사용
    public int luk;

    // -----------------------
    // 스킬 목록
    // - JobDataSO에서 복사한 SkillSO 레퍼런스 리스트를 보관합니다.
    // - SkillSO는 에셋(데이터)입니다. 공유 참조로 보관하면 메모리 효율적입니다.
    // - 실제 스킬 효과(데미지 계산, 상태 이상 적용 등)는 SkillExecutor 같은 실행기에서 처리하세요.
    // -----------------------
    [Header("스킬 (데이터 레퍼런스)")]
    public List<SkillSO> skills = new List<SkillSO>();
    // -----------------------
    // 이벤트/콜백 (선택 사항)
    // - 외부 시스템(예: UI, AI 매니저)에서 유닛 상태 변화를 듣도록 이벤트를 정의할 수 있습니다.
    // - 예: OnDeath, OnHPChanged 등
    // -----------------------
    // public event System.Action<Unit> OnDeath;
    // public event System.Action<int, int> OnHPChanged; // (current, max)
    // -----------------------
    // 초기화 메서드
    // - JobDataSO에서 값을 복사해 유닛을 초기화하는 방식입니다.
    // - 이렇게 하면 데이터(에셋)과 인스턴스 상태를 분리하여 안전하게 관리할 수 있습니다.
    // - 호출 시점: 스폰, 캐릭터 생성, 클래스 선택 직후 등
    // -----------------------
    public void InitializeFromJob(string jobId)
    {
        // JobRegistry에서 JobDataSO를 조회합니다.
        JobDataSO jd = JobRegistry.GetJob(jobId);
        if (jd == null)
        {
            Debug.LogError($"Unit.InitializeFromJob: Job '{jobId}' not found. unitId={unitId}");
            return;
        }

        // JobDataSO의 ApplyTo 메서드가 이 인스턴스의 필드를 채웁니다.
        jd.ApplyTo(this);

        // 초기화 후 추가 로직(예: UI 갱신) 필요 시 여기에 호출
        // OnHPChanged?.Invoke(hp, maxHP);
    }
    // -----------------------
    // 전투 관련 간단한 메서드들 (예시)
    // - 실제 게임에서는 더 정교한 공식(방어구 계산, 방깎, 방어 무시 등)을 적용하세요.
    // -----------------------

    // 피해 처리: hp 감소 후 사망 체크
    public void TakeDamage(int damage)
    {
        if (damage <= 0) return;

        hp -= damage;
        // HP 변화 알림(있다면 이벤트 호출)
        // OnHPChanged?.Invoke(hp, maxHP);

        if (hp <= 0)
        {
            hp = 0;
            Die();
        }
    }

    // 치료 처리: 최대치 보정
    public void Heal(int amount)
    {
        if (amount <= 0) return;
        hp = Mathf.Min(maxHP, hp + amount);
        // OnHPChanged?.Invoke(hp, maxHP);
    }

    // 사망 처리 기본 동작(예시)
    void Die()
    {
        Debug.Log($"{displayName} (id:{unitId}) died.");
        // 실제 게임: 사망 애니메이션, 이펙트, 오브젝트 풀 반환, 리스폰 로직 등 구현
        // OnDeath?.Invoke(this);
    }
    // -----------------------
    // 스킬 사용 예시
    // - 인덱스로 스킬을 선택하여 SkillExecutor에 실행을 위임합니다.
    // - 스킬 실행 전(쿨다운, MP 체크 등) 검증 로직을 여기에 추가하세요.
    // -----------------------
    public void UseSkill(int index, Unit target)
    {
        if (index < 0 || index >= skills.Count)
        {
            Debug.LogWarning("UseSkill: invalid index");
            return;
        }

        SkillSO skill = skills[index];
        if (skill == null)
        {
            Debug.LogWarning("UseSkill: skill is null");
            return;
        }

        // 예: MP가 충분한지 확인
        if (mp < skill.cost)
        {
            Debug.Log($"{displayName} 의 마나가 부족해 {skill.displayName}을 시전할 수 없었다.");
            return;
        }

        // SkillExecutor에 실행을 위임 (데이터 기반 실행)
        SkillExecutor.Execute(this, target, skill);

        // 필요 시 스킬 사용 후 쿨다운 시작, UI 갱신 등 추가 처리
    }

    // 디버그/상태 문자열 반환
    public string GetStatusString()
    {
        return $"{displayName} HP:{hp}/{maxHP} MP:{mp}/{maxMP} ATK:{atk} DEF:{def}";
    }

    public bool IsDead => hp <= 0;
}
