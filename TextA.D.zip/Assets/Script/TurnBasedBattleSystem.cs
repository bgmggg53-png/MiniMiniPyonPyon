﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

/// <summary>
/// TurnBasedBattleSystem (Manual 입력 지원 추가)
/// - Auto: 기존 자동 루프
/// - Manual: 아군 페이즈에서 플레이어 입력을 기다리고, 플레이어가 타겟 선택 시 행동 실행
/// </summary>
public class TurnBasedBattleSystem : MonoBehaviour
{
    public enum Mode { Auto, Manual }
    public enum Team { Allies, Enemy }

    public Mode mode = Mode.Auto;
    public List<Unit> allies = new List<Unit>();
    public EnemyWithParts enemy;

    public bool battleEnded { get; private set; } = false;

    // Manual 전용 상태
    private Queue<Unit> pendingAllyQueue;
    private Unit currentActingUnit;
    public bool waitingForPlayerInput { get; private set; } = false;

    private bool isAllyPhase = true;

    public event Action<Team> OnTurnStart;
    public event Action<string> OnActionLog;
    public event Action<string> OnBattleEnd;

    public void InitAndStart(List<Unit> allyList, EnemyWithParts enemyInstance)
    {
        battleEnded = false;
        allies = new List<Unit>(allyList ?? new List<Unit>());
        enemy = enemyInstance;
        if (enemy != null) enemy.ResetParts();

        if (allies.Count == 0) { Debug.LogWarning("TBS: no allies assigned."); return; }
        if (enemy == null) { Debug.LogWarning("TBS: no enemy assigned."); return; }

        Log("Battle initialized. 전투 성립 성공");
        DecideFirstTurn();

        if (mode == Mode.Auto)
            StartCoroutine(AutoBattleLoop());
        else
            StartCoroutine(ManualBattleLoop()); // Manual 전체 루프
    }

    // Auto 기존 루프 유지
    public void NextPhase()
    {
        if (battleEnded) return;
        if (mode != Mode.Manual) { Debug.LogWarning("NextPhase called but mode is not Manual."); return; }

        // 외부에서 수동으로 다음 phase 진행 (대체 API, 지금은 사용 안함 — ManualBattleLoop 내부에서 제어)
    }

    private IEnumerator AutoBattleLoop()
    {
        while (!battleEnded)
        {
            // Allies phase
            isAllyPhase = true;
            FireTurnStartEvent();
            yield return StartCoroutine(AllyPhaseRoutineOnce(null));
            if (battleEnded) break;

            // Enemy phase
            isAllyPhase = false;
            FireTurnStartEvent();
            yield return StartCoroutine(EnemyPhaseRoutineOnce(null));
            if (battleEnded) break;
        }
        FireBattleEndEvent();
    }

    // 기존 자동 아군 페이즈 (재사용)
    private IEnumerator AllyPhaseRoutineOnce(Action onComplete)
    {
        OnTurnStart?.Invoke(Team.Allies);
        var actingAllies = allies.Where(a => a != null && !a.IsDead).ToList();
        if (actingAllies.Count == 0) { Log("No allies alive. Skipping ally phase."); onComplete?.Invoke(); yield break; }

        foreach (var u in actingAllies)
        {
            if (battleEnded) yield break;
            if (u == null || u.IsDead) continue;

            var aliveParts = enemy.parts.Where(p => p != null && !p.IsDestroyed).ToList();
            if (aliveParts.Count == 0) { OnEnemyDefeated(); yield break; }

            var target = aliveParts[UnityEngine.Random.Range(0, aliveParts.Count)];
            int dmg = Mathf.Max(1, u.atk - target.def);
            target.TakeDamage(dmg);
            Log($"{u.displayName} 이(가) {target.partName} 에게 {dmg} 피해!");

            yield return new WaitForSeconds(0.15f);
            if (CheckBattleEnd()) yield break;
        }
        onComplete?.Invoke();
    }
    // Manual 전체 루프: 최초 선공 결정 후 반복 (Ally manual -> Enemy -> repeat)
    private IEnumerator ManualBattleLoop()
    {
        while (!battleEnded)
        {
            // Allies manual phase
            isAllyPhase = true;
            FireTurnStartEvent();
            yield return StartCoroutine(AllyPhaseManual());
            if (battleEnded) break;

            // Enemy phase (automatic one-action)
            isAllyPhase = false;
            FireTurnStartEvent();
            yield return StartCoroutine(EnemyPhaseRoutineOnce(null));
            if (battleEnded) break;
        }
        FireBattleEndEvent();
    }

    // Manual: 아군 하나하나에 대해 플레이어 입력을 기다림
    private IEnumerator AllyPhaseManual()
    {
        OnTurnStart?.Invoke(Team.Allies);
        var actingAllies = allies.Where(a => a != null && !a.IsDead).ToList();
        pendingAllyQueue = new Queue<Unit>(actingAllies);

        while (pendingAllyQueue.Count > 0)
        {
            currentActingUnit = pendingAllyQueue.Dequeue();
            if (currentActingUnit == null || currentActingUnit.IsDead) continue;

            Log($"{currentActingUnit.displayName} is awaiting player input.");
            waitingForPlayerInput = true;

            // UI에게 현재 유닛을 선택 대기하도록 알림(이벤트/OnActionLog 사용)
            OnActionLog?.Invoke($"Select target for {currentActingUnit.displayName}");

            // 대기 루프: UI가 PlayerActOnTarget 호출하면 waitingForPlayerInput=false로 풀림
            while (waitingForPlayerInput && !battleEnded)
                yield return null;

            // 잠깐 대기 후 다음 유닛
            yield return new WaitForSeconds(0.05f);
            if (CheckBattleEnd()) yield break;
        }
    }

    // UI에서 호출: 플레이어가 타겟을 클릭했을 때 실행시키는 API
    public void PlayerActOnTarget(EnemyPart target)
    {
        if (!waitingForPlayerInput || currentActingUnit == null || target == null) return;
        if (currentActingUnit.IsDead) { waitingForPlayerInput = false; currentActingUnit = null; return; }

        int dmg = Mathf.Max(1, currentActingUnit.atk - target.def);
        target.TakeDamage(dmg);
        Log($"{currentActingUnit.displayName} (player) attacked {target.partName} for {dmg} dmg.");

        // 완료 처리
        waitingForPlayerInput = false;
        currentActingUnit = null;
    }

    private IEnumerator EnemyPhaseRoutineOnce(Action onComplete)
    {
        OnTurnStart?.Invoke(Team.Enemy);
        yield return new WaitForSeconds(0.15f);

        var validParts = enemy.parts.Where(p => p != null && !p.IsDestroyed).ToList();
        if (validParts.Count == 0) { OnEnemyDefeated(); onComplete?.Invoke(); yield break; }

        var actingPart = validParts[UnityEngine.Random.Range(0, validParts.Count)];
        var validAllies = allies.Where(a => a != null && !a.IsDead).ToList();
        if (validAllies.Count == 0) { OnAlliesDefeated(); onComplete?.Invoke(); yield break; }

        var target = validAllies[UnityEngine.Random.Range(0, validAllies.Count)];
        int dmg = Mathf.Max(1, actingPart.attack - target.def);
        target.TakeDamage(dmg);
        Log($"{actingPart.partName} 이(가) {target.displayName} 에게 {dmg} 피해를 입혔다!");

        yield return new WaitForSeconds(0.15f);
        if (CheckBattleEnd()) { onComplete?.Invoke(); yield break; }

        onComplete?.Invoke();
    }

    // --- 기존 DecideFirstTurn, Log, CheckBattleEnd, OnEnemyDefeated, OnAlliesDefeated, FireTurnStartEvent, FireBattleEndEvent ---
    private void DecideFirstTurn()
    {
        int allySpeedSum = allies.Where(a => a != null && !a.IsDead).Sum(a => a.spd);
        int enemySpeedSum = enemy.parts.Where(p => p != null && !p.IsDestroyed).Sum(p => p.speed);
        allySpeedSum = Mathf.Max(1, allySpeedSum);
        enemySpeedSum = Mathf.Max(1, enemySpeedSum);

        int allyRoll = UnityEngine.Random.Range(0, allySpeedSum + 1);
        int enemyRoll = UnityEngine.Random.Range(0, enemySpeedSum + 1);

        Log($"코인 플립: [아군 주사위]: {allyRoll} (아군 속도:{allySpeedSum}), [적군 주사위] {enemyRoll} (적군 속도:{enemySpeedSum})");

        if (allyRoll > enemyRoll) { Log("Coin Head! 아군이 선공!"); isAllyPhase = true; return; }

        int allyLuckSum = allies.Where(a => a != null && !a.IsDead).Sum(a => a.luk);
        int luckRoll = UnityEngine.Random.Range(0, 101);
        Log($"코인 재사용 :  [아군 행운] {allyLuckSum}, [주사위 성공값] {luckRoll}");

        if (luckRoll <= allyLuckSum)
        {
            Log("럭키 스트라이크! 다시 한 번 코인 플립!");
            allyRoll = UnityEngine.Random.Range(0, allySpeedSum + 1);
            enemyRoll = UnityEngine.Random.Range(0, enemySpeedSum + 1);
            Log($"코인 플립: [아군 주사위] {allyRoll}, [적군 주사위]={enemyRoll}");
            if (allyRoll > enemyRoll) { Log("아군이 선공 기회를 잡았다!"); isAllyPhase = true; }
            else { Log("기회를 노렸지만 실패했다. 적의 선공!"); isAllyPhase = false; }
        }
        else { Log("기회를 노렸지만 실패했다. 적의 선공!"); isAllyPhase = false; }
    }

    private void Log(string msg)
    {
        Debug.Log(msg);
        OnActionLog?.Invoke(msg);
    }

    private bool CheckBattleEnd()
    {
        if (enemy == null || enemy.parts == null) return true;
        if (enemy.parts.All(p => p == null || p.IsDestroyed)) { OnEnemyDefeated(); return true; }
        if (allies == null || allies.All(a => a == null || a.IsDead)) { OnAlliesDefeated(); return true; }
        return false;
    }

    private void OnEnemyDefeated()
    {
        if (battleEnded) return;
        battleEnded = true;
        Log("아군의 승리!");
        FireBattleEndEvent();
    }

    private void OnAlliesDefeated()
    {
        if (battleEnded) return;
        battleEnded = true;
        Log("전투에서 패배했다...");
        FireBattleEndEvent();
    }

    private void FireTurnStartEvent()
    {
        OnTurnStart?.Invoke(isAllyPhase ? Team.Allies : Team.Enemy);
    }

    private void FireBattleEndEvent()
    {
        OnBattleEnd?.Invoke(battleEnded ? "전투 종료" : "일시정지");
    }
}
