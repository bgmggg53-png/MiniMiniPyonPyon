﻿using UnityEngine;

/// <summary>
/// SkillExecutor (풍부 주석 버전)
/// - 책임: SkillSO 데이터에 따라 스킬의 '실행'을 담당합니다.
/// - 역할 분리: SkillSO는 '데이터(무엇)', SkillExecutor는 '동작(어떻게)'을 처리.
/// - 확장 포인트: 범위 스킬, 크리티컬, 속성 상성, 상태 이상, VFX/SFX 매니저 연동 등.
/// </summary>
public static class SkillExecutor
{
    // Execute 메서드는 스킬의 전체 실행 흐름을 담당합니다.
    // (유효성 검사 -> 자원 체크 -> 데미지/효과 계산 -> 적용 -> 이펙트/로그)
    /// <summary>
    /// Execute:
    /// - attacker: 스킬을 사용하는 유닛(발동 주체)
    /// - target: 스킬 대상(단일 대상 예시). AOE는 별도 처리 또는 확장 필요.
    /// - skill: 실행할 스킬 데이터(SkillSO)
    /// 
    /// 흐름 요약:
    /// 1) 기본 유효성 검사 (null 체크 등)
    /// 2) 자원(MP) 체크
    /// 3) 데미지 계산(별도 함수로 분리)
    /// 4) 데미지 적용(target.TakeDamage)
    /// 5) MP 차감
    /// 6) 상태이상 처리(데이터 기반)
    /// 7) VFX/SFX 호출 및 로그 출력
    /// </summary>
    public static void Execute(Unit attacker, Unit target, SkillSO skill)
    {
        // 1) 기본 유효성 검사
        if (attacker == null)
        {
            Debug.LogWarning("SkillExecutor.Execute: attacker is null.");
            return;
        }

        if (skill == null)
        {
            Debug.LogWarning("SkillExecutor.Execute: skill is null.");
            return;
        }

        // target은 일부 스킬(자기 버프 등)에서 null일 수 있음 — 호출자와 정책을 맞추세요.
        if (target == null)
        {
            Debug.LogWarning("SkillExecutor.Execute: target is null. Treat as self/aoe or abort.");
            return;
        }
        // 2) MP(자원) 체크: 스킬 코스트보다 MP가 적으면 실행 취소
        if (attacker.mp < skill.cost)
        {
            Debug.Log($"{attacker.displayName} does not have enough MP to use {skill.displayName} (need {skill.cost}, has {attacker.mp}).");
            return;
        }

        // 3) 데미지 계산: 별도 함수에 위임하여 재사용/테스트성 향상
        int damage = CalculateDamage(attacker, target, skill);

        // (옵션) 크리티컬 처리, 랜덤 보정 등은 CalculateDamage 내부 또는 별도 단계에서 수행 가능
        // 4) 대상에 데미지 적용
        // - target.TakeDamage 내부에서 hp 감소, 사망 처리 등을 수행하도록 설계
        target.TakeDamage(damage);

        // 5) 공격자 MP 차감 (음수 방지)
        attacker.mp = Mathf.Max(0, attacker.mp - skill.cost);
        // 6) 상태 이상 처리 (데이터 필드에 따라 별도 시스템 호출)
        // - causesStatus: 단순 boolean 플래그
        // - statusEffect: 상태 이상 식별자(문자열) — 실제 적용은 상태 시스템으로 위임
        if (skill.causesStatus && !string.IsNullOrEmpty(skill.statusEffect))
        {
            // 예시: StatusEffectManager.Apply(target, skill.statusEffect, duration, strength);
            Debug.Log($"{target.displayName} afflicted with {skill.statusEffect} by {skill.displayName}.");
        }

        // 7) VFX/SFX 및 로그
        // - 이펙트 매니저가 있다면 skill.id나 skill.displayName으로 재생 요청
        //   e.g. VFXManager.Play(skill.id, target.transform.position);
        Debug.Log($"{attacker.displayName} used {skill.displayName} on {target.displayName}, dealing {damage} damage.");
    }
    /// <summary>
    /// CalculateDamage:
    /// - 데미지 산출 로직을 별도 함수로 분리하여 유지보수와 테스트 편의성 향상.
    /// - 현재 기본 공식: max(1, skill.power + attacker.atk - target.def)
    /// - 확장 포인트:
    ///   * 크리티컬(치명) 처리
    ///   * 속성 상성(요소 타입) 보정
    ///   * 랜덤 변동(±%)
    ///   * 방어구 관통, 회피, 치명저항 등
    /// </summary>
    private static int CalculateDamage(Unit attacker, Unit target, SkillSO skill)
    {
        int basePower = skill.power;      // 스킬 고유 파워
        int atkStat = attacker.atk;       // 공격자 공격력
        int defStat = target.def;         // 대상 방어력

        int raw = basePower + atkStat - defStat;

        // 최소 피해 1 보장
        int damage = Mathf.Max(1, raw);

        // TODO: 크리티컬 적용 예시
        // float crit = attacker.GetCritChance(); // 예시 메서드
        // if (Random.value < crit) damage = Mathf.RoundToInt(damage * 1.5f);

        return damage;
    }

    // ----------------------------
    // 추가 설명 및 사용 팁 (초심자용)
    // ----------------------------
    // - 데이터와 실행 분리:
    //   SkillSO는 '무엇'을 저장합니다(데이터). SkillExecutor는 '어떻게' 적용할지 결정합니다(로직).
    //   이렇게 분리하면 디자이너는 에디터에서 수치만 바꾸고 개발자는 코드를 유지 보수할 수 있습니다.
    //
    // - AOE(광역) 스킬 처리:
    //   SkillSO에 targetType(enum)을 추가하고 Execute에서 대상 목록을 수집한 뒤 반복 적용하세요.
    //
    // - 상태 이상 시스템:
    //   상태 이상(버프/디버프)은 별도 매니저(StatusEffectManager)를 만들어 책임을 위임하세요.
    //
    // - VFX/SFX:
    //   SkillSO에 vfxId/sfxId를 추가하고, SkillExecutor는 EffectManager에 재생 요청을 보냅니다.
    //
    // - 테스트:
    //   CalculateDamage 같은 순수 함수는 단위 테스트로 검증하기 좋습니다.
    //
    // - 멀티스레드(성능):
    //   연산 집약적 계산은 메인 스레드 외부로 옮길 수 있으나, 게임 상태 변경(HP 감소 등)은 반드시 메인 스레드에서 수행하세요.
    //
    // 요약: 이 클래스는 스킬 실행의 기본 뼈대입니다. 게임 요구에 맞춰 기능(크리티컬, 속성, AOE 등)을 단계적으로 확장하세요.
}

