﻿using UnityEngine;

/// <summary>
/// SkillExecutor: SkillSO 데이터에 따라 스킬을 '실행'하는 책임을 갖는 간단한 예제.
/// - 실제 게임에서는 데미지 공식, 이펙트, 범위, 상태이상 적용 등 복잡한 로직이 들어갑니다.
/// - 이 클래스는 단일 책임 원칙으로 '데이터'와 '실행'을 분리하는 데모 목적입니다.
/// </summary>
public static class SkillExecutorLegasy
{
    /// <summary>
    /// Execute: 간단한 데미지 적용 예제
    /// - attacker: 스킬을 사용하는 유닛
    /// - target: 스킬 대상 유닛
    /// - skill: SkillSO 데이터
    /// </summary>
    public static void Execute(Unit attacker, Unit target, SkillSO skill)
    {
        if (attacker == null || target == null || skill == null) return;

        // 예: 데미지 계산 (아주 간단한 식)
        int damage = Mathf.Max(1, skill.power + attacker.atk - target.def);
        target.TakeDamage(damage);

        // MP 소모 처리
        attacker.mp = Mathf.Max(0, attacker.mp - skill.cost);

        // 상태 이상 적용(데이터에 따라)
        if (skill.causesStatus && !string.IsNullOrEmpty(skill.statusEffect))
        {
            // 상태 이상 시스템이 있다면 호출
            Debug.Log($"{target.displayName} is afflicted with {skill.statusEffect}");
        }

        // 이펙트/사운드 재생은 별도 이펙트 매니저에서 처리하세요.
        Debug.Log($"{attacker.displayName} used {skill.displayName}: dealt {damage} to {target.displayName}");
    }
}