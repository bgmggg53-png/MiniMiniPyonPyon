﻿using System.Collections.Generic;
using UnityEngine;

public class EnemyWithParts : MonoBehaviour
{
    public string enemyName;
    public List<EnemyPart> parts = new List<EnemyPart>();

    // 프리팹/인스턴스 재사용 시 파트 HP 초기화
    public void ResetParts()
    {
        if (parts == null) return;
        foreach (var p in parts)
        {
            if (p == null) continue;
            p.hp = p.maxHP;
            // 필요시 추가 상태 초기화(예: IsDestroyed 플래그 등)
        }
    }
}