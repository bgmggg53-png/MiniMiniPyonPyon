﻿using UnityEngine;
using UnityEngine.EventSystems;

// EnemyPart 프리팹(또는 각 파트)에 붙여서 클릭 이벤트를 TBS로 보냄
public class EnemyPartClickHandler : MonoBehaviour, IPointerClickHandler
{
    public EnemyPart part;
    public TurnBasedBattleSystem battleSystem; // 인스펙터에 할당하거나 GameStarter에서 자동 할당

    void Awake()
    {
        if (part == null) part = GetComponent<EnemyPart>();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (battleSystem == null)
        {
            Debug.LogWarning("EnemyPartClickHandler: battleSystem not set.");
            return;
        }
        // Manual 모드에서만 유효하게 동작(방어)
        if (battleSystem.mode == TurnBasedBattleSystem.Mode.Manual)
            battleSystem.PlayerActOnTarget(part);
    }
}