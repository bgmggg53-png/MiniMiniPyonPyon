﻿// EnemyPart.cs
using UnityEngine;

public class EnemyPart : MonoBehaviour
{
    public string partName;
    public int maxHP ;
    public int hp ;

    public int speed;
    public int attack;
    public int def;

    public bool IsDestroyed => hp <= 0;

    public void TakeDamage(int damage)
    {
        damage = Mathf.Max(0, damage);
        hp -= damage;
        if (hp < 0) hp = 0;
        Debug.Log($"{partName} 부위에 {damage}피해! , 남은 HP: {hp}");
    }
}
