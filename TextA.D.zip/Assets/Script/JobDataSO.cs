﻿using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// JobDataSO : 직업(클래스) 데이터를 에디터에서 작성하고 런타임에 재사용하기 위한 ScriptableObject
/// - CreateAssetMenu 어트리뷰트로 에디터 메뉴에서 쉽게 생성 가능
/// - 스탯과 스킬 리스트를 에셋(파일)으로 보관하므로 코드 수정을 하지 않고 밸런스 조정 가능
/// - 인스턴스(유닛)는 이 데이터 에셋을 참조하거나 값들을 복사해 사용
/// </summary>
[CreateAssetMenu(menuName = "Game/JobData", fileName = "NewJobData")]
public class JobDataSO : ScriptableObject
{
    [Header("식별")]
    // 내부 ID: 레지스트리나 코드에서 조회할 키 (중복되지 않게 관리)
    public string id;

    // UI에서 보여줄 이름(예: "기사", "마법사")
    public string displayName;

    [Header("보너스 스탯 (에디터에서 조정)")]
    // 기본 공격력
    public int atk = 10;
    // 기본 방어력
    public int def = 10;
    // 최대 체력 (초기화 시 유닛의 hp에 복사)
    public int maxHP = 50;
    // 최대 마나
    public int maxMP = 20;
    // 속도/행동력 등으로 사용되는 값
    public int spd = 5;
    // 행운(치명 등)
    public int luk = 5;

    [Header("이 직업이 가진 스킬들 (에디터에서 SkillSO 에셋을 드래그)")]
    // SkillSO는 ScriptableObject로 만든 스킬 데이터 에셋입니다.
    public List<SkillSO> skills = new List<SkillSO>();

    /// <summary>
    /// ApplyTo: 이 JobDataSO의 값을 인스턴스(Unit)에 복사합니다.
    /// - 데이터(에셋)와 런타임 상태를 분리하기 위해 '복사' 방식 권장(직접 참조도 가능).
    /// - 필요한 유닛 필드가 다르면 이 메서드를 프로젝트에 맞게 수정하세요.
    /// </summary>
    public void ApplyTo(Unit target)
    {
        if (target == null) return;

        // 식별 정보 복사
        target.unitId = id;
        target.displayName = displayName;

        // 스탯 복사
        target.atk = atk;
        target.def = def;
        target.maxHP = maxHP;
        target.hp = maxHP; // 초기 HP: 최대치로 세팅
        target.maxMP = maxMP;
        target.mp = maxMP; // 초기 MP
        target.spd = spd;
        target.luk = luk;

        // 스킬 리스트는 참조 복사(에셋 공유). 필요시 깊은 복사 구현 가능
        target.skills = new List<SkillSO>(skills);
    }
}