﻿using System;
using UnityEngine;

/// <summary>
/// SkillSO : 스킬 데이터(데이터 전용, 에디터에서 편집)
/// - ScriptableObject로 정의해서 에디터에서 쉽게 생성/편집 가능
/// - 스킬의 데이터(이름, 설명, 데미지, 소모 등)만 보관하고
///   실제 실행(효과 적용)은 별도의 실행기(executor)에 위임하는 패턴을 권장합니다.
/// </summary>
[CreateAssetMenu(menuName = "Game/Skill", fileName = "NewSkill")]
public class SkillSO : ScriptableObject
{
    [Header("식별")]
    public string id;                 // 내부 ID (예: "power_slash") — 중복 방지용
    public string displayName;        // UI에 표시할 이름

    [Header("설명")]
    [TextArea] public string description;

    [Header("수치")]
    public int power = 10;            // 스킬의 기본 수치(데미지 등)
    public int cost = 0;              // 소모 자원(MP 등)
    public float cooldown = 0f;       // 쿨타임(초)
    public Type Enumtype;

    [Header("옵션(확장 가능)")]
    public bool causesStatus = false; // 상태 이상 부여 여부 플래그
    public string statusEffect;       // 예: "stun", "burn" (데이터로만 표기 — 효과는 executor에서 처리)

    // 주의:
    // - ScriptableObject는 런타임에서 공유되는 데이터입니다. 런타임 중 값을 변경하면 에셋 값이 바뀔 수 있으므로
    //   수정이 필요할 경우 복사해서 사용하거나 인스턴스화하지 마세요.
    // - 스킬의 실제 동작(데미지 계산, 이펙트 재생 등)은 여기서 구현하지 말고 별도 시스템에서 처리하세요.
}