using UnityEngine;

public class ScrollScrean : MonoBehaviour
{
    [SerializeField] float scrollSpeed = 0.5f;
    Vector2 offset;

    void Start()
    {
        
    }

    void Update()
    {
        offset.y -= scrollSpeed * Time.deltaTime;
        GetComponent<Renderer>().material.mainTextureOffset = offset;
    }
}
