﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class BattleUIController : MonoBehaviour
{
    public static BattleUIController Instance { get; private set; }

    [Header("UI")]
    public GameObject battlePanel;
    public TMP_Text logText;
    public TMP_Text turnText;
    public ScrollRect logScrollRect; // 자동 스크롤 대상

    [Header("Log settings")]
    public int maxLogLines = 80;

    private TurnBasedBattleSystem boundTBS;
    private Queue<string> logQueue = new Queue<string>();
    private string lastLog;
    int turnCount = 0;
    void Awake()
    {
        if (Instance != null && Instance != this) Destroy(this.gameObject);
        else Instance = this;
        if (battlePanel != null) battlePanel.SetActive(false);
    }

    // 안전한 바인딩: 같은 TBS에 이미 바인딩되어 있으면 무시
    public void BindToBattleSystemSafe(TurnBasedBattleSystem tbs)
    {
        if (tbs == null) return;
        if (boundTBS == tbs) return;

        UnbindFromBattleSystemSafe(boundTBS);

        boundTBS = tbs;
        boundTBS.OnActionLog += OnLog;
        boundTBS.OnActionLog += OnActionLogHandler; // 선택모드 토글용
        boundTBS.OnTurnStart += OnTurnStart;
        boundTBS.OnBattleEnd += OnBattleEnd;

        ShowBattleScreen();
    }

    public void UnbindFromBattleSystemSafe(TurnBasedBattleSystem tbs)
    {
        if (tbs == null) return;
        try
        {
            tbs.OnActionLog -= OnLog;
            tbs.OnActionLog -= OnActionLogHandler;
            tbs.OnTurnStart -= OnTurnStart;
            tbs.OnBattleEnd -= OnBattleEnd;
        }
        catch { /* ignore */ }

        if (boundTBS == tbs) boundTBS = null;
        HideBattleScreen();
    }

    // 기존(하위 호환) 바인드 메서드: 안전판 역할
    public void BindToBattleSystem(TurnBasedBattleSystem tbs) => BindToBattleSystemSafe(tbs);
    public void UnbindFromBattleSystem(TurnBasedBattleSystem tbs) => UnbindFromBattleSystemSafe(tbs);

    private void OnLog(string msg) => Log(msg);

    private void OnTurnStart(TurnBasedBattleSystem.Team team)
    {
        turnCount++;
       var s = team == TurnBasedBattleSystem.Team.Allies ? "아군 행동" : "적군 행동";
        if (turnText != null) turnText.text = s;
        Log($"■■ {turnCount}턴, {s} ■■■■");
    }

    private void OnBattleEnd(string reason) => Log($"[전투 종료] {reason}");

    public void ShowBattleScreen() { if (battlePanel != null) battlePanel.SetActive(true); }
    public void HideBattleScreen() { if (battlePanel != null) battlePanel.SetActive(false); }
    // 수동 타겟 선택 활성화: 모든 EnemyPartClickHandler에 TBS 할당
    public void EnableTargetSelection(TurnBasedBattleSystem tbs)
    {
        if (tbs == null) return;
        var handlers = FindObjectsOfType<EnemyPartClickHandler>();
        foreach (var h in handlers) h.battleSystem = tbs;
        Log("Target selection ENABLED.");
    }

    // 비활성화: 할당 제거
    public void DisableTargetSelection()
    {
        var handlers = FindObjectsOfType<EnemyPartClickHandler>();
        foreach (var h in handlers) h.battleSystem = null;
        Log("Target selection DISABLED.");
    }

    // OnActionLog 문자열을 보고 선택 모드 진입/해제 결정
    private void OnActionLogHandler(string msg)
    {
        if (string.IsNullOrEmpty(msg)) return;

        // 전투 시스템이 "Select target for <unit>" 형식으로 보낸다면 활성화
        if (msg.StartsWith("Select target for", StringComparison.OrdinalIgnoreCase))
        {
            if (boundTBS != null) EnableTargetSelection(boundTBS);
        }
        // 공격 로그나 전투 종료 로그를 받으면 선택 모드 해제
        else if (msg.IndexOf("공격받음!", StringComparison.OrdinalIgnoreCase) >= 0
              || msg.IndexOf("전투 종료.", StringComparison.OrdinalIgnoreCase) >= 0
              || msg.IndexOf("[전투 종료]", StringComparison.OrdinalIgnoreCase) >= 0)
        {
            DisableTargetSelection();
        }
    }

    // 큐 기반 로그, 중복 메시지 차단, 최대 라인 유지, 선택적 자동 스크롤
    public void Log(string message)
    {
        if (string.IsNullOrEmpty(message)) return;
        if (message == lastLog) return; // 직전과 동일한 메시지 중복 방지
        lastLog = message;

        logQueue.Enqueue(message);
        while (logQueue.Count > maxLogLines) logQueue.Dequeue();

        if (logText != null)
        {
            // 1) 텍스트 갱신
            logText.text = string.Join("\n", logQueue.ToArray());

            // 2) 강제 레이아웃 재계산 및 content height 보정 (ContentSizeFitter가 없거나 문제가 있을 때 보완)
            if (logScrollRect != null && logScrollRect.content != null)
            {
                var contentRT = logScrollRect.content;

                // 강제 레이아웃 재빌드
                UnityEngine.UI.LayoutRebuilder.ForceRebuildLayoutImmediate(contentRT);

                // TMP preferredHeight 읽기
                float prefH = logText.preferredHeight;

                // Content의 sizeDelta 조정 (y)
                Vector2 size = contentRT.sizeDelta;
                size.y = prefH;
                contentRT.sizeDelta = size;

                // 강제 업데이트 후 다음 프레임에 스크롤
                Canvas.ForceUpdateCanvases();
                StartCoroutine(ScrollNextFrame());
            }
        }

        Debug.Log(message);
    }
    private IEnumerator ScrollNextFrame()
    {
        yield return null;
        if (logScrollRect == null) yield break;
        var content = logScrollRect.content;
        var viewport = logScrollRect.viewport ?? logScrollRect.GetComponent<RectTransform>();
        if (content == null || viewport == null) yield break;

        float contentH = content.rect.height;
        float viewH = viewport.rect.height;
        float diff = Mathf.Max(0f, contentH - viewH);

        // content.pivot.y == 1 => anchoredPosition.y = diff (맨 아래)
        float targetY = content.pivot.y == 1f ? diff : -diff;
        content.anchoredPosition = new Vector2(content.anchoredPosition.x, targetY);

        // optional: ensure verticalNormalizedPosition is 0 (forces scrollbar)
        if (logScrollRect.vertical)
        {
            Canvas.ForceUpdateCanvases();
            logScrollRect.verticalNormalizedPosition = 0f;
        }
    }

    void OnDestroy()
    {
        // 안전 해제
        UnbindFromBattleSystemSafe(boundTBS);
        if (Instance == this) Instance = null;
    }
}
