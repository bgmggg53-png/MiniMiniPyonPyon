using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameStarter : MonoBehaviour
{
    [Header("Player")]
    public Unit playerUnit;
    public string startJobId = "";

    [Header("Optional Allies")]
    public List<Unit> otherAllies = new List<Unit>();
    public List<string> otherAlliesJobIds = new List<string>();

    [Header("Enemy")]
    public EnemyWithParts enemyInScene;
    public GameObject enemyPrefab;
    public Transform enemySpawnPoint;

    [Header("UI / Canvas")]
    public Canvas mainCanvas; // Inspector�� �Ҵ�
    public Image position; // ��� ���̸� ������

    [Header("Battle")]
    public TurnBasedBattleSystem battleSystem;
    public BattleUIController uiController;
    public bool autoStartBattle = true;
    public TurnBasedBattleSystem.Mode startMode = TurnBasedBattleSystem.Mode.Auto;

    void Start()
    {
        // 1) player job ����
        string playerJobToApply = null;
        if (!string.IsNullOrEmpty(startJobId)) playerJobToApply = startJobId;
        else if (playerUnit != null && !string.IsNullOrEmpty(playerUnit.unitId)) playerJobToApply = playerUnit.unitId;

        if (playerUnit != null && !string.IsNullOrEmpty(playerJobToApply))
            playerUnit.InitializeFromJob(playerJobToApply);

        // 2) otherAllies �ʱ�ȭ(������)
        for (int i = 0; i < otherAllies.Count; i++)
        {
            var ally = otherAllies[i];
            if (ally == null) continue;
            if (i < otherAlliesJobIds.Count && !string.IsNullOrEmpty(otherAlliesJobIds[i]))
                ally.InitializeFromJob(otherAlliesJobIds[i]);
        }

        // 3) enemy spawn if needed (UI prefab: parent to canvas)
        if (enemyInScene == null && enemyPrefab != null && enemySpawnPoint != null)
        {
            GameObject go;
            if (mainCanvas != null && enemyPrefab.GetComponent<RectTransform>() != null)
            {
                go = Instantiate(enemyPrefab);
                go.transform.SetParent(mainCanvas.transform, false);

                var rt = go.GetComponent<RectTransform>();
                if (rt != null)
                {
                    Vector2 localPoint;
                    Camera cam = mainCanvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : (mainCanvas.worldCamera ?? Camera.main);
                    Vector3 screenPoint = cam != null
                        ? cam.WorldToScreenPoint(enemySpawnPoint.position)
                        : RectTransformUtility.WorldToScreenPoint(null, enemySpawnPoint.position);

                    RectTransform canvasRect = mainCanvas.transform as RectTransform;
                    if (RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRect, screenPoint, cam, out localPoint))
                        rt.anchoredPosition = localPoint;
                    else
                        rt.anchoredPosition = Vector2.zero;

                    rt.localScale = Vector3.one;
                    rt.SetAsLastSibling();
                }

                enemyInScene = go.GetComponent<EnemyWithParts>();
            }
            else
            {
                go = Instantiate(enemyPrefab, enemySpawnPoint.position, enemySpawnPoint.rotation);
                enemyInScene = go.GetComponent<EnemyWithParts>();
            }

            if (enemyInScene == null) Debug.LogWarning("GameStarter: enemyPrefab has no EnemyWithParts component.");
        }
        // 4) prepare allies list
        var alliesList = new List<Unit>();
        if (playerUnit != null) alliesList.Add(playerUnit);
        foreach (var a in otherAllies) if (a != null) alliesList.Add(a);

        // 5) ensure battleSystem assigned and set mode
        if (battleSystem == null) Debug.LogError("GameStarter: battleSystem not assigned.");
        else battleSystem.mode = startMode;

        // 6) attach click handlers to enemy parts (before battle start)
        if (enemyInScene != null && enemyInScene.parts != null)
        {
            foreach (var p in enemyInScene.parts)
            {
                if (p == null) continue;
                var handler = p.GetComponent<EnemyPartClickHandler>();
                if (handler == null) handler = p.gameObject.AddComponent<EnemyPartClickHandler>();
                handler.part = p;
                handler.battleSystem = battleSystem;
            }
        }

        // 7) UI binding (safe)
        if (uiController != null && battleSystem != null) uiController.BindToBattleSystemSafe(battleSystem);
        else if (uiController == null) Debug.LogWarning("GameStarter: uiController not assigned (UI won't bind).");

        // 8) start battle
        if (battleSystem != null && autoStartBattle)
            battleSystem.InitAndStart(alliesList, enemyInScene);
    }

    // Manual ���� ��ư/�ܺ� ȣ��
    public void OnManualNextPhase()
    {
        if (battleSystem != null && battleSystem.mode == TurnBasedBattleSystem.Mode.Manual)
            battleSystem.NextPhase();
    }
}
