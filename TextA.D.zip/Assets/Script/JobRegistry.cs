﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

/// <summary>
/// JobRegistry: Resources 폴더에 저장된 JobDataSO 에셋을 런타임에 로드하여
/// id -> JobDataSO 맵으로 관리하는 간단한 레지스트리입니다.
/// - Resources 사용 예시. (Addressables을 권장하는 프로젝트에서는 구조만 바꿔 적용하세요)
/// </summary>
public static class JobRegistry
{
    // 내부 저장소: id -> JobDataSO
    private static Dictionary<string, JobDataSO> jobs;

    /// <summary>
    /// 필요 시 한 번만 로드합니다.
    /// JobDataSO 에셋은 Assets/Resources/JobData/ 폴더에 넣어 두면 Resources.LoadAll로 읽습니다.
    /// </summary>
    public static void LoadAllIfNeeded()
    {
        if (jobs != null) return;

        jobs = new Dictionary<string, JobDataSO>();

        // JobDataSO 에셋을 지정 폴더에서 모두 로드
        JobDataSO[] list = Resources.LoadAll<JobDataSO>("JobData");
        foreach (var j in list)
        {
            if (string.IsNullOrEmpty(j.id))
            {
                Debug.LogWarning($"JobDataSO '{j.name}' has empty id. Skipping.");
                continue;
            }
            if (jobs.ContainsKey(j.id))
            {
                Debug.LogWarning($"Duplicate Job id '{j.id}' found. Skipping duplicate.");
                continue;
            }
            jobs.Add(j.id, j);
        }
    }
    /// <summary>
    /// id로 JobDataSO 조회(없으면 null)
    /// </summary>
    public static JobDataSO GetJob(string id)
    {
        LoadAllIfNeeded();
        jobs.TryGetValue(id, out var job);
        return job;
    }

    /// <summary>
    /// 모든 Job 반환(읽기 전용 복사)
    /// </summary>
    public static IEnumerable<JobDataSO> GetAllJobs()
    {
        LoadAllIfNeeded();
        return jobs.Values.ToList();
    }

}


    /// <summary>id로 Job을 조회</summary>